<?php

$useragent = "xxxx";

$cookie = "xxxx";

$b = "xxxx";